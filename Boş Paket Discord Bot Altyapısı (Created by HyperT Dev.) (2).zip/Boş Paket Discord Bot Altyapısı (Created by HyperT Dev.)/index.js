import { Client, GatewayIntentBits } from 'discord.js';
import dotenv from 'dotenv';

dotenv.config();

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

client.once('ready', () => {
  console.log(`Bot aktif: ${client.user.tag}`);
  console.log(`Client ID: ${process.env.CLIENT_ID}`);
  console.log(`Ana sunucu ID: ${process.env.GUILD_ID}`);
});

client.login(process.env.DISCORD_TOKEN);
